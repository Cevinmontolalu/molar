<footer class="main-footer">
        <div class="footer-left">
          Copyright &copy; 2022 Develop by artofsomething <div class="bullet"></div> Design By <a href="https://nauval.in/">Dr</a>
        </div>
        <div class="footer-right">
          2.3.0
        </div>
</footer>