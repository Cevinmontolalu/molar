 <!-- General JS Scripts -->
 @stack('scripts')
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.nicescroll/3.7.6/jquery.nicescroll.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.24.0/moment.min.js"></script>
  <!-- <script src="{{asset('stisla-master/assets/js/stisla.js')}}"></script> -->
  
  <!-- <script type="text/javascript" src="https://code.jquery.com/jquery-3.6.0.js"></script> -->
<script type="text/javascript" src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/1.11.5/js/dataTables.bootstrap4.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/searchpanes/2.0.0/js/dataTables.searchPanes.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/searchpanes/2.0.0/js/searchPanes.bootstrap4.js"></script>
 
  <!-- JS Libraies -->
  <!-- <script src="{{asset('stisla-master/node_modules/jquery-sparkline/jquery.sparkline.min.js')}}"></script>
  <script src="{{asset('stisla-master/node_modules/chart.js/dist/Chart.min.js')}}"></script>
  <script src="{{asset('stisla-master/node_modules/owl.carousel/dist/owl.carousel.min.js')}}"></script>
  <script src="{{asset('stisla-master/node_modules/summernote/dist/summernote-bs4.js')}}"></script>
  <script src="{{asset('stisla-master/node_modules/chocolat/dist/js/jquery.chocolat.min.js')}}"></script> -->

  <!-- Template JS File -->
  <script src="{{asset('stisla-master/assets/js/scripts.js')}}"></script>
  <script src="{{asset('stisla-master/assets/js/custom.js')}}"></script>


  <!-- Page Specific JS File -->
  <!-- <script src="{{asset('stisla-master/assets/js/page/index.js')}}"></script> -->
  @if($pageName=="Transaction Team SE" || $pageName=="Transaction Team SPG")
  <script src="{{asset('stisla-master/assets/js/page/bootstrap-modal.js')}}"></script>
  @endif